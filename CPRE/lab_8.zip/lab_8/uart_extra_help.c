/*
*
*   uart_extra_help.c
* Description: This is file is meant for those that would like a little
*              extra help with formatting their code, and following the Datasheet.
*/

#include "uart_extra_help.h"
#include "timer.h"
#define REPLACE_ME 0x00


void uart_init(int baud)
{
    SYSCTL_RCGCGPIO_R |= 0b00000010;      // enable clock GPIOB (page 340)
    SYSCTL_RCGCUART_R |= 0b00000010;      // enable clock UART1 (page 344)
    GPIO_PORTB_AFSEL_R |= 0b00000011;
    GPIO_PORTB_PCTL_R  &= 0xFFFFFF00; // sets PB0 and PB1 as peripherals (page 671)
    GPIO_PORTB_PCTL_R  |= 0x00000011;       // pmc0 and pmc1       (page 688)  also refer to page 650
    GPIO_PORTB_DEN_R   |= 0b00000011;        // enables pb0 and pb1
    GPIO_PORTB_DIR_R   &= 0b11111110;        // sets pb0 as input
    GPIO_PORTB_DIR_R   |= 0b00000010;       // sets pb1 as output

    //compute baud values [UART clock= 16 MHz] 
    double fbrd;
    int    ibrd;
    int hse = 16;

//    if (UART1_CTL_R & 0x20) { //0b0010 0000
//
//    }
    fbrd = 16000000 / (hse * baud); // page 903 // 16 million is 16 MHz, Baud Rate is 115200, Clock Divisor is hse
    ibrd = (int)fbrd;

    UART1_CTL_R &= 0xFFFFFFFE;    // disable UART1 (page 918)
    hse = 8;
    UART1_IBRD_R = 8;       //(int)ibrd;        // write integer portion of BRD to IBRD
    UART1_FBRD_R = 44;      //(int)((fbrd - ibrd) * 64 + 0.5);   // write fractional portion of BRD to FBRD
    UART1_LCRH_R |= 0b01100000;        // write serial communication parameters (page 916) * 8bit and no parity
    UART1_CC_R   &= 0x0;          // use system clock as clock source (page 939)
    UART1_CTL_R |= 0b0001;        // enable UART1 and smart clock
}
void uart_sendChar(char data)
{

    // wait here as long as the FIFO is Full
   while(UART1_FR_R & 0b00100000) {
   }
   
   //send data
   UART1_DR_R = data;
}

char uart_receive(void)
{
    char data = 0;

    // keep waiting while fifo is empty
    while(UART1_FR_R & 0b00010000) {

    }

    data = (char)(UART1_DR_R & 0xFF);
    return data;
}
void uart_sendStr(const char *data)
{
    int i;
    for(i = 0; data[i] != '\0'; i++) {
        uart_sendChar(data[i]);
    }
}

// _PART3


void uart_interrupt_init()
{
    // Enable interrupts for receiving bytes through UART1
    UART1_IM_R  |= 0b00010000; //enable interrupt on receive - page 924

    // Find the NVIC enable register and bit responsible for UART1 in table 2-9
    // Note: NVIC register descriptions are found in chapter 3.4
    NVIC_EN0_R |= 0b01000000; //enable uart1 interrupts - page 104

    // Find the vector number of UART1 in table 2-9 ! UART1 is 22 from vector number page 104
    //IntRegister(INT_UART1, uart_interrupt_handler); //give the microcontroller the address of our interrupt handler - page 104 22 is the vector number

}

//void uart_interrupt_handler()
//{
//    flag = 1;
//    // Get Character
//    c = uart_receive();
//
//    // Print char to putty
//    uart_sendChar(c);
//
//    // Clear receive Interrupt
//    UART1_ICR_R |= 0x00000010;
//
//    // Wait a lil bit
//    timer_waitMicros(99);
//
//    // Mask on (re-enable the interrupt to be sent)
//    UART1_IM_R  |= 0b00010000;
//
//}
