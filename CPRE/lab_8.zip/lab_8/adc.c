#include "Timer.h"
#include "uart_extra_help.h"
#include <inc/tm4c123gh6pm.h>

void adc_init(void) {
    // Enable ADC clock for ADC Module 0
    SYSCTL_RCGCADC_R |= 0x00000001;

    // Enable clock for corresponding GPIO Port B
    SYSCTL_RCGCGPIO_R |= 0x00000002;

    timer_waitMillis(50);

    // Set GPIO AFSEL bits for ADC input pins
    // PB4 --> AIN10
    GPIO_PORTB_AFSEL_R |= 0x10;

    // set PORTB pin 4 to an input
    GPIO_PORTB_DIR_R &= ~0x10;

    // Configure AIN10 signal to be analog input an disable digital function
    GPIO_PORTB_DEN_R &= ~0x10; //0b11101111

    // Enable analog function of pin
    GPIO_PORTB_AMSEL_R |= 0x10;

    // initializes IR sensor
    GPIO_PORTB_ADCCTL_R = 0x00;

    //ADC0_ACTSS_R &= ~0x02; // enable sample sequencer 1
    ADC0_ACTSS_R |= 0x01; // enable sample sequencer 0

    ADC0_EMUX_R &= ~0x000F; // set event mux 1 to 0, must write a 1 to PSSI pin 1 to sample

    ADC0_SSMUX0_R &= ~0x000F; // clear SSMUX0
    ADC0_SSMUX0_R |= 0x000A; // set SS0 mux select to 10 (AIN10)

    ADC0_SSCTL0_R |= 0x00000006; // allow interrupt and end of sequence for 2nd sample

    ADC0_SAC_R |= 0x3; // averages 8 separate samples

    ADC0_IM_R |= 0x02; // allow SS1 Raw Interrupt Status to send
}

int adc_read(void) {

    ADC0_PSSI_R |= 0x01;
    while (ADC0_RIS_R & 0x01 == 0) { // if RIS pin 1 (SS1) is 0, stay in the loop
    }
    ADC0_ISC_R |= 0x01; // Clear SS0
    int result = ADC0_SSFIFO0_R & 0x00000FFF; // all of the bits that are 1's will become whatever is in the register(bits 0:11)
    return result;

}
