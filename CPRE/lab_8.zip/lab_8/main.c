#include "Timer.h"
#include <stdio.h>
#include "uart_extra_help.h"
#include <inc/tm4c123gh6pm.h>
#include "adc.h"

/**
 * main.c
 */
int main(void)
{
    timer_init();
    uart_init(115200);
    adc_init();

    char buffer[5];
    int analog_ir_val = adc_read();
    sprintf(buffer, "%d", analog_ir_val);
    uart_sendStr(buffer);
    uart_sendChar('\n');
    uart_sendChar('\r');
}
