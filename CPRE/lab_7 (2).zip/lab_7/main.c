/**
 * main.c
 *
 * Description: This is file is meant for those that would like a little
 *              extra help with formatting their code.
 *
 */

#define _RESET 1
#define _PART1 0
#define _PART2 0
#define _PART3 0

#include "uart_extra_help.h"
#include "lcd.h"
#include "Timer.h"
#include "movement.h"
#include "open_interface.h"
#include "cyBot_Scan.h"
#include <math.h>
#include <float.h>

//#if _RESET
////#include "Simulation_User Files_resetSimulation.h"
//#endif

// Adding global volatile varibles for communcating between
// your Interupt Service Routine, and your non-interupt code.

extern volatile  char uart_data;  // Your UART interupt code can place read data here
extern volatile  char flag;       // Your UART interupt can update this flag
                           // to indicate that it has placed new data
                           // in uart_data
typedef struct object_struct {
    int start_angle;
    int end_angle;
    int mid_angle;
    float min_sound_dist; // Distance to closest point of object
    float min_ir_dist;
    char isStarted;
} object_t;

//void writeLine(char* str) {
//    int i;
//    for(i = 0; str[i] != '\0'; ++i) {
//        cyBot_sendByte(str[i]);
//    }
//    cyBot_sendByte('\n');
//    cyBot_sendByte('\r');
//}

void scan() {
    cyBOT_Scan_t scanData;
    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);
    int i = 0;

    char scanText[50];

    object_t objs[6];
    int numObjects = 0;
    objs[0].isStarted = '\0';

    cyBOT_SERVRO_cal_t servoBounds;
    servoBounds.right = 0;
    servoBounds.left = 180;

    int angle = servoBounds.right;
    cyBOT_Scan(angle, &scanData);
    timer_waitMillis(1000);
    float last_distance = 0;
    double sum_ir = 0;

    uart_sendStr("\n\rDegrees |  Distance (cm)\n\r");
    for(angle = servoBounds.right; angle <= servoBounds.left; angle+=2) { // Increment angle by x

        cyBOT_Scan(angle, &scanData);
        for (i = 0; i < 2; ++i) {
            cyBOT_Scan(angle, &scanData);
            sum_ir += scanData.IR_raw_val;
        }
        double ir_avg = sum_ir / (double)2;
        sum_ir = 0;

        //timer_waitMillis(5);   // decrease

        //double ir_dist = 30000000 * pow((double)scanData.IR_raw_val, -1.907);
        double ir_dist = 30000000 * pow(ir_avg, -1.907);

        if(fabs(last_distance - ir_dist) > 10) { // if distance changes by more than x cm, new object
            if(objs[numObjects].isStarted) {
                if(angle - objs[numObjects].start_angle > 4) {  // object must exist for x degrees
                    objs[numObjects].end_angle = angle;
                    numObjects++;
                    objs[numObjects].isStarted = '\0';
                }
                else {
                    objs[numObjects].isStarted = '\0';
                }
            }
            if((ir_dist < 80) && !(objs[numObjects].isStarted)) { // must be closer than x cm
                objs[numObjects].isStarted = 'T';
                objs[numObjects].start_angle = angle;
                objs[numObjects].min_ir_dist = ir_dist;
                objs[numObjects].min_sound_dist = scanData.sound_dist;
                objs[numObjects].mid_angle = angle;
            }
        } else if(objs[numObjects].isStarted && objs[numObjects].min_ir_dist > ir_dist) {
            objs[numObjects].min_ir_dist = ir_dist;
            objs[numObjects].min_sound_dist = scanData.sound_dist;

        }
        last_distance = ir_dist;
        sprintf(scanText, "%d\t%f\t%lf\n\r", angle, scanData.sound_dist, ir_dist);
        uart_sendStr(scanText);
    }
    if((angle - objs[numObjects].start_angle > 10) && (objs[numObjects].isStarted)) {
        objs[numObjects].end_angle = angle;
        numObjects++;
    }


    char buff[20];
    int smallest_width_index = 0;
    float smallest_width = 400;
    uart_sendStr("Object#\t\tAngle\t\tPING Distance\tIR Distance\tWidth");
    for(i = 0; i < numObjects; i++) {
        float width = 2 * objs[i].min_ir_dist * sin(((objs[i].end_angle - objs[i].start_angle) / 2) * (M_PI / 180));
        if(width < smallest_width) {
            smallest_width = width;
            smallest_width_index = i;
        }
        float ir_distance = objs[i].min_ir_dist;
        float sound_distance = objs[i].min_sound_dist;
         objs[i].mid_angle = (objs[i].start_angle + objs[i].end_angle) / 2;

        sprintf(buff, "\n\r%d\t\t%d\t\t%d\t\t%d\t\t%d", i+1, objs[i].mid_angle, (int)sound_distance,(int)ir_distance, (int)width);
        uart_sendStr(buff);

    }


    sprintf(buff, "\n\n\r%d\t\t%d\t\t%d", smallest_width_index + 1, objs[smallest_width_index].mid_angle, (int)smallest_width);
    uart_sendStr(buff);

    cyBOT_Scan(objs[smallest_width_index].mid_angle, &scanData);

    if (toggle_flag == 1) {
        turn(90 - objs[smallest_width_index].mid_angle, sensor_data);
        move_dynamic((objs[smallest_width_index].min_sound_dist * 10) - 50, sensor_data);
    }
    return;
}

void uart_interrupt_handler()
{
    flag = 1;
    // Get Character
    uart_data = uart_receive();

    // Print char to putty
    uart_sendChar(uart_data);

    // Clear receive Interrupt
    UART1_ICR_R |= 0x00000010;

    // Wait a lil bit
    timer_waitMicros(99);

    // Mask on (re-enable the interrupt to be sent)
    UART1_ICR_R &= 0xFFFFFFEF;

}

void main()
{

    timer_init();
    lcd_init();
    uart_init(115200);
    uart_interrupt_init();

    oi_t *sensor_data = oi_alloc();
    oi_init(sensor_data);

    cyBOT_init_Scan(0b0111);
    // cyBOT_SERVO_cal();


    right_calibration_value = 238000;
    left_calibration_value = 1219750;

    oi_update(sensor_data);
    uart_sendStr("\r\nBeep Beep\r\n");
    toggle_flag = 0;

    while(uart_data != 'q') {
       if (flag) { // switch case ?
           // Move forward with w
           if(uart_data == 'w') {
               move_forward(100, sensor_data);
           }
           // Move backward with w
           else if(uart_data == 's') {
               move_backward(100, sensor_data);
           }
           // Turn left with a
           else if(uart_data == 'a') {
               turn(-30, sensor_data);
           }
           // Turn right with d
           else if(uart_data == 'd') {
               turn(30, sensor_data);
           } else if(uart_data == 'm') {
               scan();
           }
           else if(uart_data == 't') {
               uart_sendStr("\r\nToggling modes\r\n");
              toggle_flag = !toggle_flag;
//              scan();
//              toggle_flag = !toggle_flag;
          }
       }
       flag = 0;
   }

    lcd_putc(uart_data);
    oi_update(sensor_data);

    oi_setWheels(0,0);
    oi_free(sensor_data);
    return;
}

