#include "open_interface.h"

// Moves forward given distance
void move_forward(double distance, oi_t* sensor_data);

// Moves backward given distance
void move_backward(double distance, oi_t* sensor_data);

// Moves forward and dynamically avoids objects
void move_dynamic(double distance, oi_t* sensor_data);

// Turns at given angle
void turn(double angle, oi_t* sensor_data);
