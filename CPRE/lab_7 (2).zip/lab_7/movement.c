#include "open_interface.h"
#include "movement.h"
#include <math.h>

#define off 8.5

void move_dynamic(double distance, oi_t* sensor_data) {
    oi_setWheels(169,169);
    double sum = 0;
    double distance_to_ob = 0;
    while (sum < distance) {
        oi_update(sensor_data);
        if (sensor_data->bumpLeft) {
            distance_to_ob = sum;
            move_backward(150, sensor_data);
            turn(90, sensor_data); //cw
            move_forward(150, sensor_data);
            turn(90, sensor_data);
            move_forward(distance, sensor_data);
            turn(-90, sensor_data); // ccw
            //sum += distance - distance_to_ob;
            distance_to_ob = 0;
            oi_setWheels(169,169);
//            while(sum < distance) {
//                oi_update(sensor_data);
//                sum += sensor_data->distance;
//            }
            oi_setWheels(0,0);
            continue;
        }
        else if(sensor_data->bumpRight) {
            distance_to_ob = sum;
            move_backward(150, sensor_data);
            turn(-90, sensor_data);
            move_forward(150, sensor_data);
            turn(90, sensor_data);
            move_forward(distance, sensor_data);
            // move_forward(distance - distance_to_ob, sensor_data);
            turn(90, sensor_data);
            //sum += distance - distance_to_ob;
            distance_to_ob = 0;
            oi_setWheels(169, 169);
//            while(sum < distance) {
//                oi_update(sensor_data);
//                sum += sensor_data->distance;
//            }
            oi_setWheels(0,0);
            continue;
        }
        sum += sensor_data->distance;
    }
    oi_setWheels(0,0);
}

void move_forward(double distance, oi_t* sensor_data) {
    oi_setWheels(169,169);
    double sum = 0;
    while (sum < distance) {
        oi_update(sensor_data);
        sum += sensor_data->distance;
    }
    oi_setWheels(0,0);
}

void move_backward(double distance, oi_t* sensor_data) {
    double sum = 0;
    oi_setWheels(-169, -169);
    while (sum < distance) {
        oi_update(sensor_data);

        sum -= sensor_data->distance;
        }
        oi_setWheels(0,0);
}

void turn(double angle, oi_t* sensor_data) {
    if (angle > 0) {
        oi_setWheels(-169,169);
    }
    else {
        oi_setWheels(169,-169);
    }
    double sum = 0;
    while (fabs(sum) < fabs(angle) - off) {
        oi_update(sensor_data);
        sum += sensor_data->angle;
    }
    oi_setWheels(0,0);
}

